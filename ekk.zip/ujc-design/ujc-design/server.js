require('dotenv').config();
const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const path = require('path');
const { Pool } = require('pg');

const app = express();
const PORT = process.env.PORT || 3000;

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432', 10),
  database: process.env.DB_NAME || 'conferences_rf',
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'conferences-rf-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 },
}));

const STATUS_LABELS = {
  new: 'Новая',
  scheduled: 'Мероприятие назначено',
  completed: 'Мероприятие завершено',
};

function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: 'Необходима авторизация' });
  next();
}

function requireAdmin(req, res, next) {
  if (!req.session.userId || req.session.role !== 'admin') {
    return res.status(403).json({ error: 'Доступ запрещён' });
  }
  next();
}

function validateLogin(login) {
  return /^[a-zA-Z0-9]{6,}$/.test(login);
}

function validatePassword(password) {
  return password.length >= 8;
}

function parseDate(str) {
  const m = str.match(/^(\d{2})\.(\d{2})\.(\d{4})$/);
  if (!m) return null;
  const d = new Date(+m[3], +m[2] - 1, +m[1]);
  if (d.getDate() !== +m[1] || d.getMonth() !== +m[2] - 1) return null;
  return d;
}

function isDbAuthError(err) {
  return err && (err.code === '28P01' || /password authentication failed/i.test(err.message || ''));
}

function isDbMissingError(err) {
  return err && err.code === '3D000';
}

async function ensureDbConnection() {
  try {
    await pool.query('SELECT 1 AS ok');
  } catch (err) {
    if (isDbAuthError(err)) {
      console.error('\nОшибка подключения к PostgreSQL: неверный пароль.');
      console.error('Проверьте в файле .env значение DB_PASSWORD (пароль пользователя postgres).');
    } else if (isDbMissingError(err)) {
      console.error('\nОшибка подключения: база не найдена.');
      console.error('Запустите: npm run init-db');
    } else {
      console.error('\nОшибка подключения к PostgreSQL:', err.message);
    }
    process.exit(1);
  }
}

// --- Auth ---

app.post('/api/register', async (req, res) => {
  const { login, password, fullName, phone, email } = req.body;
  const errors = {};

  if (!login || !validateLogin(login)) {
    errors.login = 'Логин: только латиница и цифры, минимум 6 символов';
  }
  if (!password || !validatePassword(password)) {
    errors.password = 'Пароль: минимум 8 символов';
  }
  if (!fullName || fullName.trim().length < 2) {
    errors.fullName = 'Укажите ФИО';
  }
  if (!phone || phone.trim().length < 5) {
    errors.phone = 'Укажите контактный телефон';
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    errors.email = 'Укажите корректный e-mail';
  }

  if (Object.keys(errors).length) return res.status(400).json({ errors });

  try {
    const exists = await pool.query('SELECT id FROM users WHERE login = $1', [login]);
    if (exists.rows.length) {
      return res.status(400).json({ errors: { login: 'Такой логин уже занят' } });
    }

    const hash = await bcrypt.hash(password, 10);
    await pool.query(
      'INSERT INTO users (login, password, full_name, phone, email) VALUES ($1,$2,$3,$4,$5)',
      [login, hash, fullName.trim(), phone.trim(), email.trim()]
    );
    res.json({ success: true, message: 'Регистрация успешна! Войдите в систему.' });
  } catch (err) {
    if (isDbAuthError(err)) return res.status(500).json({ error: 'Ошибка БД: проверьте пароль в .env' });
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

app.post('/api/login', async (req, res) => {
  const { login, password } = req.body;
  if (!login || !password) {
    return res.status(400).json({ error: 'Введите логин и пароль' });
  }

  try {
    const result = await pool.query('SELECT * FROM users WHERE login = $1', [login]);
    if (!result.rows.length) {
      return res.status(401).json({ error: 'Неверный логин или пароль' });
    }

    const user = result.rows[0];
    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).json({ error: 'Неверный логин или пароль' });
    }

    req.session.userId = user.id;
    req.session.login = user.login;
    req.session.role = user.role;
    req.session.fullName = user.full_name;

    res.json({
      success: true,
      role: user.role,
      fullName: user.full_name,
    });
  } catch (err) {
    res.status(500).json({ error: 'Ошибка сервера' });
  }
});

app.post('/api/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/api/me', (req, res) => {
  if (!req.session.userId) return res.json({ authenticated: false });
  res.json({
    authenticated: true,
    login: req.session.login,
    fullName: req.session.fullName,
    role: req.session.role,
  });
});

// --- Reference data ---

app.get('/api/rooms', async (req, res) => {
  const result = await pool.query('SELECT id, name, description FROM rooms ORDER BY id');
  res.json(result.rows);
});

app.get('/api/payment-methods', async (req, res) => {
  const result = await pool.query('SELECT id, name FROM payment_methods ORDER BY id');
  res.json(result.rows);
});

// --- Applications ---

app.post('/api/applications', requireAuth, async (req, res) => {
  if (req.session.role === 'admin') {
    return res.status(403).json({ error: 'Администратор не может создавать заявки' });
  }

  const { roomId, startDate, paymentMethodId } = req.body;
  const errors = {};

  if (!roomId) errors.roomId = 'Выберите помещение';
  const parsed = parseDate(startDate);
  if (!parsed) errors.startDate = 'Дата в формате ДД.ММ.ГГГГ';
  if (!paymentMethodId) errors.paymentMethodId = 'Выберите способ оплаты';

  if (Object.keys(errors).length) return res.status(400).json({ errors });

  try {
    await pool.query(
      `INSERT INTO applications (user_id, room_id, start_date, payment_method_id)
       VALUES ($1, $2, $3, $4)`,
      [req.session.userId, roomId, parsed, paymentMethodId]
    );
    res.json({ success: true, message: 'Заявка отправлена администратору' });
  } catch (err) {
    res.status(500).json({ error: 'Ошибка сохранения заявки' });
  }
});

app.get('/api/applications/my', requireAuth, async (req, res) => {
  const result = await pool.query(`
    SELECT a.id, r.name AS room, a.start_date, pm.name AS payment_method,
           a.status, a.created_at,
           rev.id AS review_id, rev.text AS review_text, rev.rating
    FROM applications a
    JOIN rooms r ON r.id = a.room_id
    JOIN payment_methods pm ON pm.id = a.payment_method_id
    LEFT JOIN reviews rev ON rev.application_id = a.id
    WHERE a.user_id = $1
    ORDER BY a.created_at DESC
  `, [req.session.userId]);

  const apps = result.rows.map(row => ({
    ...row,
    statusLabel: STATUS_LABELS[row.status],
    canReview: row.status !== 'new' && !row.review_id,
    startDateFormatted: formatDate(row.start_date),
  }));

  res.json(apps);
});

// --- Reviews ---

app.post('/api/reviews', requireAuth, async (req, res) => {
  const { applicationId, text, rating } = req.body;

  if (!text || text.trim().length < 5) {
    return res.status(400).json({ error: 'Отзыв должен содержать минимум 5 символов' });
  }
  if (!rating || rating < 1 || rating > 5) {
    return res.status(400).json({ error: 'Оценка от 1 до 5' });
  }

  try {
    const app = await pool.query(
      'SELECT * FROM applications WHERE id = $1 AND user_id = $2',
      [applicationId, req.session.userId]
    );
    if (!app.rows.length) return res.status(404).json({ error: 'Заявка не найдена' });
    if (app.rows[0].status === 'new') {
      return res.status(400).json({ error: 'Отзыв можно оставить после обработки заявки' });
    }

    const existing = await pool.query(
      'SELECT id FROM reviews WHERE application_id = $1', [applicationId]
    );
    if (existing.rows.length) {
      return res.status(400).json({ error: 'Отзыв уже оставлен' });
    }

    await pool.query(
      'INSERT INTO reviews (user_id, application_id, text, rating) VALUES ($1,$2,$3,$4)',
      [req.session.userId, applicationId, text.trim(), rating]
    );
    res.json({ success: true, message: 'Отзыв сохранён' });
  } catch (err) {
    res.status(500).json({ error: 'Ошибка сохранения отзыва' });
  }
});

// --- Admin ---

app.get('/api/admin/applications', requireAdmin, async (req, res) => {
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(50, parseInt(req.query.limit) || 10);
  const offset = (page - 1) * limit;
  const sortBy = ['created_at', 'start_date', 'status'].includes(req.query.sortBy)
    ? req.query.sortBy : 'created_at';
  const sortDir = req.query.sortDir === 'asc' ? 'ASC' : 'DESC';
  const statusFilter = req.query.status || '';
  const search = req.query.search || '';

  let where = 'WHERE 1=1';
  const params = [];
  let idx = 1;

  if (statusFilter && ['new', 'scheduled', 'completed'].includes(statusFilter)) {
    where += ` AND a.status = $${idx++}`;
    params.push(statusFilter);
  }
  if (search) {
    where += ` AND (u.full_name ILIKE $${idx} OR u.login ILIKE $${idx} OR r.name ILIKE $${idx})`;
    params.push(`%${search}%`);
    idx++;
  }

  const countResult = await pool.query(`
    SELECT COUNT(*) AS count FROM applications a
    JOIN users u ON u.id = a.user_id
    JOIN rooms r ON r.id = a.room_id
    ${where}
  `, params);

  params.push(limit, offset);
  const result = await pool.query(`
    SELECT a.id, u.login, u.full_name, r.name AS room,
           a.start_date, pm.name AS payment_method, a.status, a.created_at
    FROM applications a
    JOIN users u ON u.id = a.user_id
    JOIN rooms r ON r.id = a.room_id
    JOIN payment_methods pm ON pm.id = a.payment_method_id
    ${where}
    ORDER BY a.${sortBy} ${sortDir}
    LIMIT $${idx++} OFFSET $${idx}
  `, params);

  res.json({
    total: parseInt(countResult.rows[0].count),
    page,
    limit,
    totalPages: Math.ceil(parseInt(countResult.rows[0].count) / limit),
    data: result.rows.map(row => ({
      ...row,
      statusLabel: STATUS_LABELS[row.status],
      startDateFormatted: formatDate(row.start_date),
    })),
  });
});

app.patch('/api/admin/applications/:id/status', requireAdmin, async (req, res) => {
  const { status } = req.body;
  if (!['new', 'scheduled', 'completed'].includes(status)) {
    return res.status(400).json({ error: 'Недопустимый статус' });
  }

  const result = await pool.query(
    'UPDATE applications SET status = $1 WHERE id = $2 RETURNING id',
    [status, req.params.id]
  );
  if (!result.rows.length) return res.status(404).json({ error: 'Заявка не найдена' });

  res.json({
    success: true,
    message: `Статус изменён: ${STATUS_LABELS[status]}`,
    statusLabel: STATUS_LABELS[status],
  });
});

function formatDate(date) {
  const d = new Date(date);
  const day = String(d.getDate()).padStart(2, '0');
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const year = d.getFullYear();
  return `${day}.${month}.${year}`;
}

app.listen(PORT, () => {
  console.log(`Конференция.РФ (design) запущен: http://localhost:${PORT}`);
}).on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`\nПорт ${PORT} занят. Измените PORT в файле .env (например, 3002)`);
    console.error('Или закройте другой процесс: netstat -ano | findstr :' + PORT);
  } else {
    console.error('Ошибка запуска:', err.message);
  }
  process.exit(1);
});

(async () => {
  await ensureDbConnection();
})();
