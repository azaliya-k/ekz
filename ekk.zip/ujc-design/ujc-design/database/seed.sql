-- Начальные данные для Конференции.РФ
\c conferences_rf;

-- Помещения
INSERT INTO rooms (name, description) VALUES
    ('Аудитория',  'Большой зал для конференций до 200 человек'),
    ('Коворкинг',  'Пространство для небольших встреч до 30 человек'),
    ('Кинозал',    'Зал с проектором для презентаций до 80 человек');

-- Способы оплаты
INSERT INTO payment_methods (name) VALUES
    ('Наличные'),
    ('Банковская карта'),
    ('Безналичный расчёт');

-- Администратор (логин: Admin26, пароль: Demo20)
-- Пароль захеширован bcrypt (cost 10)
INSERT INTO users (login, password, full_name, phone, email, role) VALUES
    ('Admin26', '$2b$10$rQZ8KjYxH5vN3mP6wL9sUeJ4fG2hK1nM0pQ7rS5tU8vW3xY6zA9bC', 'Администратор системы', '+7 (900) 000-00-00', 'admin@conferences.rf', 'admin');
