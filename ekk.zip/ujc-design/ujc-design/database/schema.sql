-- Конференции.РФ — схема базы данных PostgreSQL
-- Для построения ER-диаграммы используйте эти таблицы и связи

-- Роли пользователей
CREATE TYPE user_role AS ENUM ('user', 'admin');

-- Статусы заявок
CREATE TYPE application_status AS ENUM (
    'new',           -- Новая
    'scheduled',     -- Мероприятие назначено
    'completed'      -- Мероприятие завершено
);

-- Пользователи
CREATE TABLE users (
    id          SERIAL PRIMARY KEY,
    login       VARCHAR(50)  NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    full_name   VARCHAR(200) NOT NULL,
    phone       VARCHAR(20)  NOT NULL,
    email       VARCHAR(100) NOT NULL,
    role        user_role    NOT NULL DEFAULT 'user',
    created_at  TIMESTAMP    NOT NULL DEFAULT NOW()
);

-- Помещения (аудитория, коворкинг, кинозал)
CREATE TABLE rooms (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE,
    description TEXT
);

-- Способы оплаты
CREATE TABLE payment_methods (
    id          SERIAL PRIMARY KEY,
    name        VARCHAR(100) NOT NULL UNIQUE
);

-- Заявки на бронирование
CREATE TABLE applications (
    id                  SERIAL PRIMARY KEY,
    user_id             INTEGER            NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    room_id             INTEGER            NOT NULL REFERENCES rooms(id),
    start_date          DATE               NOT NULL,
    payment_method_id   INTEGER            NOT NULL REFERENCES payment_methods(id),
    status              application_status NOT NULL DEFAULT 'new',
    created_at          TIMESTAMP          NOT NULL DEFAULT NOW()
);

-- Отзывы (только после смены статуса администратором)
CREATE TABLE reviews (
    id              SERIAL PRIMARY KEY,
    user_id         INTEGER   NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    application_id  INTEGER   NOT NULL UNIQUE REFERENCES applications(id) ON DELETE CASCADE,
    text            TEXT      NOT NULL,
    rating          SMALLINT  NOT NULL CHECK (rating BETWEEN 1 AND 5),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Индексы для фильтрации и сортировки в админ-панели
CREATE INDEX idx_applications_status     ON applications(status);
CREATE INDEX idx_applications_start_date ON applications(start_date);
CREATE INDEX idx_applications_user_id    ON applications(user_id);
CREATE INDEX idx_reviews_user_id         ON reviews(user_id);
