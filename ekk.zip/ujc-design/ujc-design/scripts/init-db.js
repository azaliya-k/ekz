require('dotenv').config();
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const { Pool } = require('pg');

const ADMIN_LOGIN = 'Admin26';
const ADMIN_PASSWORD = 'Demo20';

function splitSqlStatements(sql) {
  // простое разбиение по ; (для нашего schema.sql достаточно)
  return sql
    .split(';')
    .map(s => s.trim())
    .filter(Boolean);
}

async function ensureDatabaseExists() {
  const adminPool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432', 10),
    database: process.env.DB_ADMIN_DB || 'postgres',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
  });

  const dbName = process.env.DB_NAME || 'conferences_rf';
  const exists = await adminPool.query('SELECT 1 FROM pg_database WHERE datname = $1', [dbName]);
  if (!exists.rows.length) {
    try {
      // CREATE DATABASE не поддерживает IF NOT EXISTS во всех окружениях
      await adminPool.query(`CREATE DATABASE ${dbName}`);
      console.log('Создана база:', dbName);
    } catch (err) {
      // 42P04: duplicate_database
      if (err.code === '42P04') {
        console.log('База уже существует:', dbName);
      } else {
        throw err;
      }
    }
  } else {
    console.log('База уже существует:', dbName);
  }

  await adminPool.end();
}

async function applySchemaAndSeed() {
  const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432', 10),
    database: process.env.DB_NAME || 'conferences_rf',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
  });

  const schemaPath = path.join(__dirname, '../database/schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf8');

  const statements = splitSqlStatements(schema).filter(stmt => {
    // пропускаем команды psql (\c) и CREATE DATABASE из schema.sql
    const head = stmt
      .replace(/^\uFEFF/, '')
      .replace(/^(?:--.*\r?\n)*/g, '')
      .trim();
    if (/^\s*\\c\b/i.test(head)) return false;
    if (/^\s*CREATE\s+DATABASE\b/i.test(head)) return false;
    return true;
  });

  const client = await pool.connect();
  try {
    for (const stmt of statements) {
      try {
        await client.query(stmt);
      } catch (err) {
        // игнорируем "already exists"
        if (err.code === '42P07' || err.code === '42710') continue;
        throw err;
      }
    }

    // seed справочников
    await client.query(`
      INSERT INTO rooms (name, description) VALUES
        ('Аудитория', 'Большой зал для конференций до 200 человек'),
        ('Коворкинг', 'Пространство для небольших встреч до 30 человек'),
        ('Кинозал', 'Зал с проектором для презентаций до 80 человек')
      ON CONFLICT (name) DO NOTHING
    `);

    await client.query(`
      INSERT INTO payment_methods (name) VALUES
        ('Наличные'),
        ('Банковская карта'),
        ('Безналичный расчёт')
      ON CONFLICT (name) DO NOTHING
    `);

    // админ
    const adminHash = await bcrypt.hash(ADMIN_PASSWORD, 10);
    await client.query(
      `
        INSERT INTO users (login, password, full_name, phone, email, role)
        VALUES ($1, $2, 'Администратор системы', '+7 (900) 000-00-00', 'admin@conferences.rf', 'admin')
        ON CONFLICT (login) DO UPDATE SET password = EXCLUDED.password
      `,
      [ADMIN_LOGIN, adminHash]
    );

    console.log('\nБаза данных инициализирована!');
    console.log('Админ:', `${ADMIN_LOGIN} / ${ADMIN_PASSWORD}`);
  } finally {
    client.release();
    await pool.end();
  }
}

async function main() {
  await ensureDatabaseExists();
  await applySchemaAndSeed();
}

main().catch(err => {
  console.error('Ошибка инициализации:', err.message || err);
  console.error('\nПроверьте, что PostgreSQL установлен и запущен, и параметры в .env верные.');
  process.exit(1);
});
