function showAlert(id, message, type = 'error') {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = message;
  el.className = `alert alert-${type} show`;
}

function hideAlert(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove('show');
}

function setFieldError(fieldId, message) {
  const group = document.getElementById(fieldId)?.closest('.form-group');
  if (!group) return;
  group.classList.add('has-error');
  const msg = group.querySelector('.error-msg');
  if (msg) msg.textContent = message;
}

function clearFieldErrors(form) {
  form.querySelectorAll('.form-group').forEach(g => {
    g.classList.remove('has-error');
  });
}

async function api(url, options = {}) {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  });
  const data = await res.json();
  if (!res.ok) throw data;
  return data;
}

async function checkAuth(redirectTo = '/login.html') {
  try {
    const me = await api('/api/me');
    if (!me.authenticated) {
      window.location.href = redirectTo;
      return null;
    }
    return me;
  } catch {
    window.location.href = redirectTo;
    return null;
  }
}

function getInitials(fullName) {
  if (!fullName) return '?';
  const parts = fullName.trim().split(/\s+/);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return fullName.slice(0, 2).toUpperCase();
}

function setupUserSidebar(me) {
  const nameEl = document.getElementById('sidebarUserName');
  const avatarEl = document.getElementById('sidebarAvatar');
  if (nameEl) nameEl.textContent = me.fullName || me.login;
  if (avatarEl) avatarEl.textContent = getInitials(me.fullName);
}

function initSlider() {
  const track = document.querySelector('.slider-track');
  const dots = document.querySelectorAll('.slider-dots span');
  if (!track) return;

  let current = 0;
  const total = track.children.length;
  let timer;

  function goTo(index) {
    current = (index + total) % total;
    track.style.transform = `translateX(-${current * 100}%)`;
    dots.forEach((d, i) => d.classList.toggle('active', i === current));
  }

  function next() { goTo(current + 1); }
  function prev() { goTo(current - 1); }

  function startAuto() {
    clearInterval(timer);
    timer = setInterval(next, 3000);
  }

  document.querySelector('.slider-btn.next')?.addEventListener('click', () => { next(); startAuto(); });
  document.querySelector('.slider-btn.prev')?.addEventListener('click', () => { prev(); startAuto(); });
  dots.forEach((d, i) => d.addEventListener('click', () => { goTo(i); startAuto(); }));

  startAuto();
}

function formatDateInput(input) {
  input.addEventListener('input', (e) => {
    let v = e.target.value.replace(/\D/g, '');
    if (v.length >= 2) v = v.slice(0, 2) + '.' + v.slice(2);
    if (v.length >= 5) v = v.slice(0, 5) + '.' + v.slice(5, 9);
    e.target.value = v;
  });
}
